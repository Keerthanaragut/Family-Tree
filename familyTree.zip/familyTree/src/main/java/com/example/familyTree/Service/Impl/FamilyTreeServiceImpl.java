package com.example.familyTree.Service.Impl;

import java.util.List;


import com.example.faimlyTree.Repository.RegisterRepository;
import com.example.familyTree.Model.Register;
import com.example.familyTree.Service.FamilyTreeService;

public class FamilyTreeServiceImpl implements FamilyTreeService{

	private RegisterRepository RegisterRepository;
	public FamilyTreeServiceImpl(RegisterRepository RegisterRepository) {
		this.RegisterRepository = RegisterRepository;
	}
	@Override
	public List<Register> getAllRegister() {
		// TODO Auto-generated method stub
		return RegisterRepository.findAll();
	}

	@Override
	public Register saveUser(Register user) {
		// TODO Auto-generated method stub
		return RegisterRepository.save(user);
	}

	@Override
	public Register getUserById(Long id) {
		// TODO Auto-generated method stub
		return RegisterRepository.findById(id).get();
	}

	@Override
	public Register updateUser(Register user) {
		// TODO Auto-generated method stub
		return RegisterRepository.save(user);
	}

	@Override
	public void deleteUserById(Long id) {
		// TODO Auto-generated method stub
		RegisterRepository.deleteById(id);
	}

}
