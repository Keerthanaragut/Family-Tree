package com.example.familyTree.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.faimlyTree.Repository.RegisterRepository;
import com.example.familyTree.Model.Register;

@Controller
public class HomeController {
	 @Autowired
	    private RegisterRepository RegisterRepository;
	     
	    @GetMapping("")
	    public String viewHomePage() {
	        return "Home";
	    }
	    @GetMapping("/Register")
	    public String showRegistrationForm(Model model) {
	        model.addAttribute("user", new Register());
	         
	        return "Register";
	    }
}
