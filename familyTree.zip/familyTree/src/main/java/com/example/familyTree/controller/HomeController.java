package com.example.familyTree.controller;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

//import com.SpringClasses.DogSchMgmt.Model.DogSch;
import com.example.faimlyTree.Repository.RegisterRepository;
import com.example.familyTree.Model.Login;
import com.example.familyTree.Model.Register;

@Controller
public class HomeController {
	    //@Autowired
	    private RegisterRepository RegisterRepository;
	     
	    @GetMapping("/home")
	    public String viewHomePage(Model model) {
	    	model.addAttribute("user", new Login());
	        return "Home";
	    }
//	    @GetMapping("/home")
//	    public String viewHomePage() {
//	    	//model.addAttribute("user", new Register());
//	        return "Home";
//	    }
	    @GetMapping("/Register")
	    public String showRegistrationForm(Model model) {
	        model.addAttribute("user", new Register());
	         
	        return "Register";
	    }
	    @GetMapping("/Login")
	    public String showLoginForm(Model model) {
//	    	DogSch dog=new  DogSch();
//	    	model.addAttribute("dog", dog);
//	    	return "add";
	        model.addAttribute("user", new Login());
	         
	        return "Login";
	    }
}
