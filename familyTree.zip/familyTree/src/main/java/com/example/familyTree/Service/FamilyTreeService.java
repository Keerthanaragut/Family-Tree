package com.example.familyTree.Service;

import java.util.List;


import com.example.familyTree.Model.Register;

public interface FamilyTreeService {
	public List<Register> getAllRegister();  
	public Register saveUser(Register user);
	public Register getUserById(Long id);
	public Register updateUser(Register user);
	public void deleteUserById(Long id);


}
