package com.example.faimlyTree.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.familyTree.Model.Login;

public interface LoginRepository extends JpaRepository<Login, Long> {

}
