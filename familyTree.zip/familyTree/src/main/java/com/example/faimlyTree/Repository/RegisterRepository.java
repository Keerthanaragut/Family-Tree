package com.example.faimlyTree.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.familyTree.Model.Register;

public interface RegisterRepository extends JpaRepository<Register, Long> {

}
